Milestone 2
Team Number 21
0200_Anthony
1100_Robert

This directory contains PDF snapshots of our current progress for all deliverables. 
These snapshots are under the main, Team_21 folder.

Sub-directories contain .xlsx work files of each deliverable indicated in the folder name.

The zipped, ETL program will export data from OLTP databases and import the data into the Star Schema OLAP database.

